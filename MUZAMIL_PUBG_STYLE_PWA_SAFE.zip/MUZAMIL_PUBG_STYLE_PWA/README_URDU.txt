MUZAMIL PUBG STYLE - PWA PACKAGE

یہ ایک آزاد Fan-made ڈیزائن گیلری ہے۔ اس میں صرف آؤٹ فٹس، ہیلمٹس، بیگز اور گاڑیوں کے تصوری ڈیزائن ہیں۔ یہ PUBG/Krafton کی سرکاری ایپ نہیں، اور PUBG میں کوئی آئٹم unlock یا تبدیل نہیں کرتی۔

پیکج میں index.html, styles.css, app.js, manifest.webmanifest, sw.js اور icons شامل ہیں۔

ضروری بات: موبائل کے اندر ZIP یا content:// فائل سے PWA انسٹال نہیں ہوتی۔ پہلے تمام فائلیں HTTPS ویب ہوسٹنگ پر اپ لوڈ کریں۔ پھر Chrome میں HTTPS لنک کھولیں اور Install app یا Add to Home screen دبائیں۔
