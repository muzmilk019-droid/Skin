const items = [
["M416","Gun Skins","Aurora Gold","gun","#e8c77e","#5b431d"],["AKM","Gun Skins","Crimson Ember","gun","#e36a55","#591d1a"],["M762","Gun Skins","Obsidian Pulse","gun","#a78bce","#38234f"],["SCAR-L","Gun Skins","Desert Mirage","gun","#d7b46a","#66502b"],["AUG","Gun Skins","Neon Circuit","gun","#72d6c5","#1b5b59"],["GROZA","Gun Skins","Royal Inferno","gun","#e4a24e","#71351b"],["ACE32","Gun Skins","Arctic Alloy","gun","#a9cde0","#34566b"],["G36C","Gun Skins","Jungle Phantom","gun","#9bb77c","#344c2d"],["QBZ","Gun Skins","Solar Flare","gun","#e6bd65","#69451e"],["FAMAS","Gun Skins","Violet Storm","gun","#b69be2","#453064"],
["AWM","Gun Skins","Frost Monarch","gun","#a9d9ee","#315b7a"],["M24","Gun Skins","Sandstone Elite","gun","#d5ad70","#5c4227"],["KAR98K","Gun Skins","Silver Frontier","gun","#c4c4c4","#555"],["Mosin Nagant","Gun Skins","Winter Camo","gun","#d0e1e8","#60717a"],["AMR","Gun Skins","Titanium Core","gun","#d2b77e","#62502d"],["UZI","Gun Skins","Cyber Flash","gun","#f08d65","#73351e"],["UMP45","Gun Skins","Night Runner","gun","#8f9bd5","#343d73"],["Vector","Gun Skins","Toxic Circuit","gun","#9acb74","#405e27"],["Thompson","Gun Skins","Vintage Gold","gun","#d7b46a","#70501f"],["P90","Gun Skins","Pulse Drive","gun","#65c8d8","#245c68"],
["Urban Phantom","Outfits","Shadow Operative","outfit","#b7a0d8","#3b3151"],["Golden Vanguard","Outfits","Royal Armor","outfit","#e3c16e","#71501d"],["Arctic Ranger","Outfits","Frost Suit","outfit","#b9d9e8","#426276"],["Crimson Agent","Outfits","Redline Set","outfit","#df756b","#692c2b"],["Desert Scout","Outfits","Dune Walker","outfit","#d2ad77","#70502e"],["Neon Striker","Outfits","Cyber Suit","outfit","#7bd5c9","#245b58"],
["Tactical Pack","Gear & Backpacks","Carbon Black","gear","#aeb6bf","#454b50"],["Royal Backpack","Gear & Backpacks","Gilded Crest","gear","#e4c477","#72521f"],["Frost Helmet","Gear & Backpacks","Ice Guard","gear","#a9d9ee","#315b7a"],["Phantom Helmet","Gear & Backpacks","Night Ops","gear","#a78bce","#38234f"],["Combat Vest","Gear & Backpacks","Iron Shield","gear","#9b9b9b","#343434"],["Crimson Pack","Gear & Backpacks","Red Ember","gear","#df756b","#692c2b"],
["Gold Coupe","Vehicle Skins","Golden Velocity","vehicle","#e8c77e","#5b431d"],["Neon Sports Car","Vehicle Skins","Electric Pulse","vehicle","#72d6c5","#1b5b59"],["Desert UAZ","Vehicle Skins","Sandstorm Camo","vehicle","#d7b46a","#66502b"],["Arctic Buggy","Vehicle Skins","Frozen Trail","vehicle","#a9d9ee","#315b7a"],["Royal Motorcycle","Vehicle Skins","King's Ride","vehicle","#b69be2","#453064"],["Crimson Dacia","Vehicle Skins","Redline Racer","vehicle","#e36a55","#591d1a"]
];
const categories=["All","Gun Skins","Outfits","Gear & Backpacks","Vehicle Skins"];
let active="All",favoritesOnly=false;
const grid=document.getElementById("itemGrid"),search=document.getElementById("searchInput"),filters=document.getElementById("filters"),dialog=document.getElementById("previewDialog");
let favorites=new Set();try{favorites=new Set(JSON.parse(localStorage.getItem("muzamilVaultFavorites")||"[]"))}catch(e){}
function visual(item){return `<div class="visual ${item[3]}" style="--light:${item[4]};--dark:${item[5]}">${item[3]==="outfit"?"":item[3]==="gear"?"":item[3]==="vehicle"?"":""}</div>`}
function renderFilters(){filters.innerHTML=categories.map(c=>`<button class="filter ${c===active?"active":""}" data-category="${c}">${c.toUpperCase()}</button>`).join("")}
function render(){
 const q=search.value.trim().toLowerCase();
 const shown=items.filter(x=>(active==="All"||x[1]===active)&&(!favoritesOnly||favorites.has(x[0]))&&x.slice(0,3).join(" ").toLowerCase().includes(q));
 grid.innerHTML=shown.map(x=>`<article class="item-card"><div class="card-art">${visual(x)}</div><div class="card-meta"><small>${x[1].toUpperCase()}</small><h3>${x[0]}</h3><p>${x[2]} · Concept</p><div class="card-actions"><button data-preview="${x[0]}">VIEW PREVIEW</button><button class="fav" aria-label="Favorite ${x[0]}" data-fav="${x[0]}">${favorites.has(x[0])?"★":"☆"}</button></div></div></article>`).join("");
 document.getElementById("emptyState").hidden=shown.length>0;document.getElementById("totalCount").textContent=items.length;document.getElementById("favoriteCount").textContent=favorites.size;
}
filters.addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;active=b.dataset.category;renderFilters();render()});
search.addEventListener("input",render);
document.getElementById("favoritesToggle").addEventListener("click",e=>{favoritesOnly=!favoritesOnly;e.currentTarget.textContent=favoritesOnly?"★ SHOW ALL":"☆ FAVORITES";render()});
grid.addEventListener("click",e=>{
 const f=e.target.closest("[data-fav]");if(f){const n=f.dataset.fav;favorites.has(n)?favorites.delete(n):favorites.add(n);try{localStorage.setItem("muzamilVaultFavorites",JSON.stringify([...favorites]))}catch(err){}render();return}
 const b=e.target.closest("[data-preview]");if(!b)return;const x=items.find(i=>i[0]===b.dataset.preview);
 document.getElementById("previewName").textContent=x[0];document.getElementById("previewCategory").textContent=x[1];document.getElementById("previewSkin").textContent=x[2];document.getElementById("previewArt").innerHTML=visual(x);dialog.showModal();
});
document.getElementById("closeDialog").addEventListener("click",()=>dialog.close());dialog.addEventListener("click",e=>{if(e.target===dialog)dialog.close()});
renderFilters();render();