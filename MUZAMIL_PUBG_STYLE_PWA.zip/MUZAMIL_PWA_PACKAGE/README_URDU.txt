MUZAMIL PUBG STYLE - PWA PACKAGE

اہم بات:
یہ فائلیں براہِ راست موبائل کی فائلوں سے کھولنے پر Install App نہیں بنیں گی۔ PWA انسٹال کرنے کے لیے انہیں HTTPS ویب ہوسٹنگ پر اپ لوڈ کرنا ضروری ہے۔

اس پیکج میں:
- index.html
- styles.css
- app.js
- manifest.webmanifest
- sw.js (offline cache)
- icons (192px اور 512px)

ہوسٹنگ کے بعد:
1) HTTPS ویب ایڈریس Chrome میں کھولیں۔
2) Chrome کے تین نقطے کھولیں۔
3) Install app یا Add to Home screen منتخب کریں۔

یہ آزاد fan-made preview gallery ہے، PUBG/Krafton سے وابستہ نہیں۔ یہ PUBG میں آئٹمز unlock یا modify نہیں کرتی۔
